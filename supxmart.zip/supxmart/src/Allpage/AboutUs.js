import React from 'react'
import Navbar from '../Pages/Navbar'
import SideBar from '../Pages/SideBar'
import About from '../Pages/About'
import BreadCrumb from '../Pages/BreadCrumb'
import Team from '../Pages/Team'
import Footer from '../Pages/Footer'
import Testimonial from '../Pages/Testimonial'

export default function AboutUs() {
    return (
        <>
         <Navbar/>
         <BreadCrumb tracer="About"/>
         <SideBar/>   
         <About/>
            <div className="team" >
	    	    <div className="container ">
                    <h3>Amazing Team</h3>
                    <div className="agileits_team_grids">
                        
                        <Team name="Abhishek Sahu" designation="Founder"/>
                        <Team name="Navneet Chaudhary" designation="Manager"/>
                        <Team name="Ziyaual hak" designation="Manager"/>
                        <Team name="Atul sahu" designation="Manager"/>
                        <div className="clearfix"> </div>
			        </div>
		        </div>
	        </div>
          
           <Footer/> 
        </>
    )
}

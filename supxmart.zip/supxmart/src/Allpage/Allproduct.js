import React from 'react'
import BreadCrumb from '../Pages/BreadCrumb'
import Footer from '../Pages/Footer'
import Navbar from '../Pages/Navbar'
import Product from '../Pages/Product'
import SideBar from '../Pages/SideBar'

export default function Allproduct() {
    return (
        <>
         <Navbar/>   
         <BreadCrumb tracer="All Product"/>
         <SideBar/>
         <Product/>
         <Footer/>
        </>
    )
}

import React from 'react'

import Navbar from '../Pages/Navbar'
 import Banner from '../Pages/Banner';
 import Offer from '../Pages/Offer';
 import Hotoffer from '../Pages/Hotoffer';
 import TopProduct from '../Pages/TopProduct';
 import Footer from '../Pages/Footer'
export default function Home() {
    return (
        <>
        <Navbar />
        <Banner/>
        <Offer/>
        <Hotoffer/>
        <TopProduct/>
        <Footer/> 
        </>
    )
}


import AboutUs from './Allpage/AboutUs';
import Contact from './Allpage/Contact';
import Home from './Allpage/Home';
import './App.css';
import Allproduct from './Allpage/Allproduct';

import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';
import ApiTest from './Pages/ApiTest';
import Log_in from "./Pages/log_in";



function App() {
  return (
    <>

{/*<ApiTest/>*/}

    {<div>
     <Router>
     <Switch>
     
     <Route path="/aboutus" component={AboutUs}/>
     <Route path="/contact" component={Contact}/>
     <Route path="/allproduct" component={Allproduct}/>
     <Route path="/" component={Home}/>
     </Switch>
     </Router> 
    </div> }
   
    {/* <Home/> */}
    {/* <AboutUs/> */}
     {/* <Contact/> */}
    {/*  <Allproduct/> */}
    {/*<Log_in/>*/}
    
</>
  );
}

export default App;

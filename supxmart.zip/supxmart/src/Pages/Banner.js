import React from 'react'
import SideBar from './SideBar'

export default function Banner() {
    return (
    <div className="banner">
		<SideBar/>
		<div className="w3l_banner_nav_right">
			<section className="slider">
				<div className="flexslider">
					<ul className="slides">
						<li>
							<div className="w3l_banner_nav_right_banner">
								<h3>Make your <span>food</span> with Spicy.</h3>
								<div className="more">
									<a href="products.html" className="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
								</div>
							</div>
						</li>
						<li>
							<div className="w3l_banner_nav_right_banner1">
								<h3>Make your <span>food</span> with Spicy.</h3>
								<div className="more">
									<a href="products.html" className="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
								</div>
							</div>
						</li>
						<li>
							<div className="w3l_banner_nav_right_banner2">
								<h3>upto <i>50%</i> off.</h3>
								<div className="more">
									<a href="products.html" className="button--saqui button--round-l button--text-thick" data-text="Shop now">Shop now</a>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</section>
		
				{/* script is here */}
			
		</div>
		<div className="clearfix"></div>
	</div>
    )
}

import React, { useEffect,useState } from 'react'
export default function ApiTest(){
    const [data,setData]=useState([])
    useEffect(()=>{
        fetch(" https://fakestoreapi.com/products")
        .then((result) =>{result.json().then((resp) =>{
            setData(resp)
            console.warn("result=",resp)
        })
        })
        
    },[])
    return(
        <div>
               <table border="1">
                
                   <tr>
                       <td>ID</td>
                       <td>Name</td>
                       <td>Email</td>
                       <td>Phone</td>
                   </tr>
                   
                   {
                       data.map((item) =>
                       
                   // <tbody>  
                   <tr>
                       <td>{item.id}</td>
                       <td><img src={item.image}></img> </td>
                       <td>{item.AboutUs}</td>
                       <td>{item.price}</td>
                       
                   </tr>
                       
                   //</tbody> 
    
    
                   )
    }
                
               </table>
            </div>
    );
}
/*
export default class ApiTest extends Component {

    constructor(props){

        super(props);
        this.state= {
            posts:[],
        };

    }

    
    componentDidMount(){

        fetch("http://localhost:8080/API/index.php")
        .then((response) => response.json())
        .then((result) => {

            this.setState({
                posts : result.data,
            });
        })

    }

    render() {

        const {posts} = this.state;
        return (
            <div>
               <table>
                  <thead>
                   <tr>
                       <td>ID</td>
                       <td>Name</td>
                       <td>Email</td>
                       <td>Phone</td>
                   </tr>
                   </thead>
                   {
                       posts.map((post) =>
                   // <tbody>  
                   <tr>
                       <td>{post.id}</td>
                       <td>{post.name} </td>
                       <td>Email</td>
                       <td>Phone</td>
                   </tr>
                   //</tbody> 
    
    
                   )
    }
                
               </table>
            </div>
        )
    }
}
*/
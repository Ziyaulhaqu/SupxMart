import React, { useState } from "react";
import RecipeDetails from "./RecipeDetails";

const Recipe = ({ recipe }) => {
  const [show, setShow] = useState(false);
  const { label, image, url, ingredients } = recipe.recipe;

  return (
    <div className="recipe" style={{float:"left", width:"320px",height:"320px"}}>
      <center>
      <h2>{label}</h2><br/><br/>
      <img src={image} alt={label} /><br/>
      <a href={url} target="_blank" rel="noopener noreferrer">
        URL
      </a><br/>
      <button onClick={() => setShow(!show)}>Ingredients</button><br/><br/>
      {show && <RecipeDetails ingredients={ingredients} />}<br/><br/>
      </center>
      <hr/>
      <br/><br/>
    </div>
  );
};

export default Recipe;
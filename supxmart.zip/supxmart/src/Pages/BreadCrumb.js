import React from 'react'

export default function BreadCrumb(props) {
    return (
        <>
           {/* <!-- products-breadcrumb --> */}
	<div className="products-breadcrumb">
		<div className="container">
			<ul>
				<li><i className="fa fa-home" aria-hidden="true"></i><a href="index.html">Home</a><span>|</span></li>
				<li>{props.tracer}</li>
			</ul>
		</div>
	</div>
{/* <!-- //products-breadcrumb -->  */}
        </>
    )
}

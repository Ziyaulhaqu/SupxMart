import React from 'react'
import ProductItem from './ProductItem'

export default function Product() {
    return (
        <>
            <div className="w3l_banner_nav_right">
                <div className="w3l_banner_nav_right_banner8">
                    <h3>Best Deals For New Products<span className="blink_me"></span></h3>
                </div>
                <div className="w3ls_w3l_banner_nav_right_grid w3ls_w3l_banner_nav_right_grid_sub">
                    <h3 className="w3l_fruit">Bread & Bakery</h3>
                    <div className="w3ls_w3l_banner_nav_right_grid1 w3ls_w3l_banner_nav_right_grid1_veg">
                        <div className="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asdfdfd">

                        <ProductItem/>

                        </div>
                        <div className="col-md-3 w3ls_w3l_banner_left">

                            <ProductItem/>

                        </div>
                        <div className="col-md-3 w3ls_w3l_banner_left w3ls_w3l_banner_left_asd">
                        
                            <ProductItem/>
                        
                        </div>
                        <div className="col-md-3 w3ls_w3l_banner_left">

                            <ProductItem/>

                        </div>
                        <div className="clearfix"> </div>
				    </div>
                </div>
            </div>
            <div className="clearfix"></div> 
        </>
    );
}

import React from 'react'

export default function testimonial() {
    return (
    <>
        <div className="w3_testimonials_grids">
					<div className="wmuSlider example1 animated wow slideInUp" data-wow-delay=".5s">
						<div className="wmuSliderWrapper">
							<article style={{position: 'absolute', width: '100%', opacity: '0'}}> 
								<div className="banner-wrap">
									<div className="col-md-6 w3_testimonials_grid">
										<p><i className="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores 
											repellat.</p>
										<h4>Andrew Smith <span>Customer</span></h4>
									</div>
									<div className="col-md-6 w3_testimonials_grid">
										<p><i className="fa fa-quote-right" aria-hidden="true"></i>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
											voluptatibus maiores alias consequatur aut perferendis doloribus asperiores 
											repellat.</p>
										<h4>Thomson Richard <span>Customer</span></h4>
									</div>
									<div className="clearfix"> </div>
								</div>
							</article> 
                        </div>
                    </div>

                    {/* script  */}
        </div>
                    
    </>
    )
}

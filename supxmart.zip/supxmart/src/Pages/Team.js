import React from 'react'

export default function team(props) {
    return (
        <>
              
                                <div className="col-md-3 agileits_team_grid">
                                    <img src="../assests/images/32.jpg" alt=" " className="img-responsive" />
                                    <h4>{props.name}</h4>
                                    <p>{props.designation}</p>
                                    <ul className="agileits_social_icons agileits_social_icons_team">
                                        <li><a href="#" className="facebook"><i className="fa fa-facebook" aria-hidden="true"></i></a></li>
                                        <li><a href="#" className="twitter"><i className="fa fa-twitter" aria-hidden="true"></i></a></li>
                                        <li><a href="#" className="google"><i className="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                               
        </>
    )
}

//import React from 'react'
import {Link} from 'react-router-dom';
import React, { useState } from "react";
import Axios from "axios";
import { v4 as uuidv4 } from "uuid";
import Recipe from "./Recipe";
import Alert from "./Alert";

import Log_in from "./log_in";
import Log from "./log";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';




export default function Navbar() {
    

    const [modal, setModal] = useState(false);

    const toggle = () => setModal(!modal); 
    
     


    const [query, setQuery] = useState("");
    const [recipes, setRecipes] = useState([]);
    const [alert, setAlert] = useState("");
  
    const APP_ID = "4e9f05eb";
    const APP_KEY = "9b904d703fa0d46a88ce1ac63f29f498";
  
    const url = `https://api.edamam.com/search?q=${query}&app_id=${APP_ID}&app_key=${APP_KEY}`;
    const getData = async () => {
        if (query !== "") {
          const result = await Axios.get(url);
          if (!result.data.more) {
            return setAlert("No food with such name");
          }
          console.log(result);
          setRecipes(result.data.hits);
          setQuery("");
          setAlert("");
        } else {
          setAlert("Please fill the form");
        }
      };
    
      const onChange = e => setQuery(e.target.value);
    
      const onSubmit = e => {
        e.preventDefault();
        getData();
      };  
    return (
            <>   
         {/* <!-- header --> */}
         
        <div className="agileits_header">
            <div className="w3l_offers">
                <a href="products.html">Today's special Offers !</a>
            </div>
            <div className="w3l_search">
                <form action="#" method="post" onSubmit={onSubmit}>
                    <input type="text" name="Product" placeholder="Search a product..."  required="" onChange={onChange} value={query} autoComplete="off"/>
                    <input type="submit" value=" "/>
                    {/*<button className="btn btn-outline-light" type="submit">Search</button> */}
                </form>
            </div>
            <div className="product_list_header">  
                <form action="#" method="post" className="last">
                    <fieldset>
                        <input type="hidden" name="cmd" value="_cart" />
                        <input type="hidden" name="display" value="1" />
                        <input type="submit" name="submit" value="View your cart" className="button" />
                    </fieldset>
                </form>
            </div>
            
           {/* <div className="w3l_header_right">
                <ul>
                    <li className="dropdown profile_details_drop">
                        <a href="#" className="dropdown-toggle" data-toggle="dropdown"><i className="fa fa-user" aria-hidden="true"></i><span className="caret"></span></a>
                        <div className="mega-dropdown-menu">
                            <div className="w3ls_vegetables">
                                <ul className="dropdown-menu drp-mnu">
                                    {/*<li><a href="login.html">Login</a></li> *
                                   
                                      <Log_in />  
                                    
                                    
                                    <li><a href="login.html">Sign Up</a></li>
                                    
                          
                                </ul>
                                
                            </div>                  
                        </div>	
                    </li>
                </ul>
            </div>
    */} 
                                      <a href="ziya.html">login</a>        
            <div className="w3l_header_right1">
                <h2><Link to="/contact">Contact Us</Link></h2>
            </div>
            <div className="clearfix"> </div>
        </div>
    {/* <!-- script-for sticky-nav --> */}
        {/* its script in index.html */}
    {/* </div><!-- //script-for sticky-nav --> */}
    <div className="recipes" item-aria-flowto="left"> 
        {recipes !== [] &&
          recipes.map(recipe => <Recipe key={uuidv4()} recipe={recipe} />)}
      </div>
        <div className="logo_products">
            <div className="container">
                <div className="w3ls_logo_products_left">
                    <h1><Link to="/"><span>SupX</span> Mart</Link></h1>
                </div>
                <div className="w3ls_logo_products_left1">
                    <ul className="special_items">
                        
                        <li><Link to="/aboutus">About Us</Link><i>/</i></li>
                        <li><Link to="/allproduct">All products</Link><i>/</i></li>
                        <li><Link to="/service">Services</Link></li>
                    </ul>
                </div>
                <div className="w3ls_logo_products_left1">
                    <ul className="phone_email">
                        <li><i className="fa fa-phone" aria-hidden="true"></i>(+0123) 234 567</li>
                        <li><i className="fa fa-envelope-o" aria-hidden="true"></i><a href="mailto:store@grocery.com">store@grocery.com</a></li>
                    </ul>
                </div>
                <div className="clearfix"> </div>
            </div>
       
        </div>
          
    {/* <!-- //header --> */}
         </>     
    )
}
